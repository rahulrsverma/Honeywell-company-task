const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs').promises;
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;
const FILE_PATH = 'data.txt';

app.use(bodyParser.json());
app.use(cors());

// Read data from file
async function readDataFromFile() {
    try {
        const data = await fs.readFile(FILE_PATH, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

// Write data to file
async function writeDataToFile(data) {
    try {
        await fs.writeFile(FILE_PATH, JSON.stringify(data, null, 2), 'utf8');
    } catch (error) {
        console.error('Error writing to file:', error);
    }
}

// Create Data
app.post('/api/data', async (req, res) => {
    try {
        const newData = req.body;
        const data = await readDataFromFile();
        newData.id = data.length > 0 ? data[data.length - 1].id + 1 : 1;
        data.push(newData);
        await writeDataToFile(data);
        res.json(newData);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Read All Data
app.get('/api/data', async (req, res) => {
    try {
        const data = await readDataFromFile();
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Update Data
app.put('/api/data/:id', async (req, res) => {
    try {
        const updatedData = req.body;
        const data = await readDataFromFile();
        const index = data.findIndex(item => item.id === parseInt(req.params.id));
        if (index !== -1) {
            data[index] = { ...data[index], ...updatedData };
            await writeDataToFile(data);
            res.json(data[index]);
        } else {
            res.status(404).json({ error: 'Data not found' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Delete Data
app.delete('/api/data/:id', async (req, res) => {
    try {
        const data = await readDataFromFile();
        const index = data.findIndex(item => item.id === parseInt(req.params.id));
        if (index !== -1) {
            const deletedItem = data.splice(index, 1)[0];
            await writeDataToFile(data);
            res.json(deletedItem);
        } else {
            res.status(404).json({ error: 'Data not found' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
