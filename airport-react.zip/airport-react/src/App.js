import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
    const [data, setData] = useState([]);
    const [formData, setFormData] = useState({ name: '', location: '', code: '', terminal: '', status: '' });
    const [selectedItem, setSelectedItem] = useState(null);

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/data');
            setData(response.data);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:5000/api/data', formData);
            fetchData();
            setFormData({ name: '', location: '', code: '', terminal: '', status: '' });
        } catch (error) {
            console.error('Error adding data:', error);
        }
    };

    const handleDelete = async (id) => {
        try {
            await axios.delete(`http://localhost:5000/api/data/${id}`);
            fetchData();
        } catch (error) {
            console.error('Error deleting data:', error);
        }
    };

    const handleRadioChange = (id) => {
        setSelectedItem(id);
    };

    return (
        <div>
            <h1>Airport Data</h1>
            <form onSubmit={handleSubmit}>
                <input type="text" name="name" placeholder="Name" value={formData.name} onChange={handleInputChange} />
                <input type="text" name="location" placeholder="Location" value={formData.location} onChange={handleInputChange} />
                <input type="text" name="code" placeholder="Code" value={formData.code} onChange={handleInputChange} />
                <input type="text" name="terminal" placeholder="Terminal" value={formData.terminal} onChange={handleInputChange} />
                <input type="text" name="status" placeholder="Status" value={formData.status} onChange={handleInputChange} />
                <button type="submit">Add</button>
            </form>
            <ul>
                {data.map(item => (
                    <li key={item.id}>
                        <input type="radio" name="selectedItem" checked={selectedItem === item.id} onChange={() => handleRadioChange(item.id)} />
                        <strong>{item.name}</strong> - {item.location} ({item.code})
                        <button onClick={() => handleDelete(item.id)}>Delete</button>
                    </li>
                ))}
            </ul>
            <select value={selectedItem} onChange={(e) => setSelectedItem(e.target.value)}>
                <option value="">Select an item</option>
                {data.map(item => (
                    <option key={item.id} value={item.id}>{item.name}</option>
                ))}
            </select>
        </div>
    );
}

export default App;
